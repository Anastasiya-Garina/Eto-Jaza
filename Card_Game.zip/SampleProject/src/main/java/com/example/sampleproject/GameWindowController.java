package com.example.sampleproject;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

public class GameWindowController {
    int iii = 0;
    int n = 36;
    String[] deck = new String[n];

    @FXML
    private Button newGameStart;

    @FXML
    private GridPane deskAttackCardPane;

    @FXML
    private GridPane deskAnswerCardPane;
    
    @FXML
    private ScrollPane firstPlayerScroll;

    @FXML
    private ScrollPane secondPlayerScroll;

    @FXML
    private FlowPane firstPlayerPane;

    @FXML
    private FlowPane secondPlayerPane;

    @FXML
     public void addCardOnTable(CardController card) throws IOException {
    	FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Card.fxml"));
    	Pane newPane = (Pane)loader.load();
    	CardController cardController = loader.getController();
    	cardController.setCardParameters(card.getNominal(), card.getMask(), this, newPane);
//        if (((String) card.cardPane.parent.value.id).value == "secondPlayerPane") deskAnswerCardPane.add(newPane, deskAnswerCardPane.getChildren().size(), 0);
        deskAttackCardPane.add(newPane, deskAttackCardPane.getChildren().size(), 0);
    }
    @FXML
    void addCard(String nominal_, String mask_, boolean l_r) throws IOException  {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Card.fxml"));
        Pane newPane = (Pane)loader.load();
        CardController cardController = loader.getController();
        cardController.setCardParameters(nominal_, mask_, this, newPane);
        if (l_r) {
            firstPlayerPane.getChildren().add(newPane);
            firstPlayerScroll = new ScrollPane();
            firstPlayerScroll.setContent(firstPlayerPane);
        } else {
            secondPlayerPane.getChildren().add(newPane);
            secondPlayerScroll = new ScrollPane();
            secondPlayerScroll.setContent(secondPlayerPane);
        }
    }

    @FXML
    void koloda(ActionEvent event) throws IOException, InterruptedException {
        int cardsPerPlayer = 6;
        int players = 2 ;
        if (iii > 2)  return;
        if (iii == 0) {
            String[] suits = {"♠","♣", "♥", "♦"};
            String[] rank = {"6", "7", "8", "9", "10","J", "Q", "K", "A"};
            n = suits.length * rank.length; // количество карт
            for (int i = 0; i < rank.length; i++) {
                for (int j = 0; j < suits.length; j++) {
                    deck[suits.length*i + j] = rank[i] + " " + suits[j];
                }
            }
            iii++;
        }
        else
            iii++;
        for (int i = 0; i < n; i++) {
            int r = i + (int) (Math.random() * (n-i)); // случайная карта в колоде
            String temp = deck[r];
            deck[r] = deck[i];
            deck[i] = temp;
        }
        for (int i = 0; i < players * cardsPerPlayer; i++) {
            String[] karts = deck[i].split(" ");
            addCard(karts[0], karts[1],  i % 2 == 1);
        }
    }
}
